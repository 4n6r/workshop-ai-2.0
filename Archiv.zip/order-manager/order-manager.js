import express from 'express';
import { v4 as uuidv4, validate as validateUUID } from 'uuid';
import chalk from "chalk";

const log = console.log;

const success = x => console.log(chalk.green(x));
const error = x => console.log(chalk.red(x));
const info = x => console.log(chalk.yellow(x));

const app = express();
app.use(express.json());

app.post('/api/orders', (req, res) => {
    const { sourceAccountId, targetIban, recipient, description, amount } = req.body;
    success(`POST: new order from account ${sourceAccountId} to IBAN ${targetIban}, recip ${recipient} and desc ${description} for amount ${amount}`);
    // Basic validation
    if (!validateUUID(sourceAccountId)) {
        error('Invalid sourceAccountId (must be UUID)');
        return res.status(400).json({ error: 'Invalid sourceAccountId (must be UUID)' });
    }
    if (typeof targetIban !== 'string' || typeof recipient !== 'string' || typeof description !== 'string') {
        error('targetIban, recipient, and description must be strings');
        return res.status(400).json({ error: 'targetIban, recipient, and description must be strings' });
    }

    // Simulate order creation
    const orderId = uuidv4();
    const order = {
        orderId,
        sourceAccountId,
        targetIban,
        recipient,
        description,
        amount,
        status: 'created'
    };

    res.status(201).json(order);
});

const PORT = process.env.PORT || 3004;
app.listen(PORT, () => {
    info(`Order Manager API running on port ${PORT}`);
});
