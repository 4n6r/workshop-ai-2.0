import express from 'express';
import {v4 as uuidv4} from 'uuid';
import chalk from 'chalk';
const app = express();

const success = x => console.log(chalk.green(x));
const error = x => console.log(chalk.red(x));
const info = x => console.log(chalk.yellow(x));

app.use(express.json());

// Sample in-memory accounts and transactions
const accounts = [
  {
    id: "9c453024-2997-4ce6-9834-abe544f8f380",
    iban: "DE89 3704 0044 0532 0130 00",
    product_type: "current_account",
    opening_date: "2020-01-15",
    balance: 2500.75
  },
  {
    id: "cc8135fa-43d6-4de5-92f3-fc7c621cb328",
    iban: "DE12 3456 7890 1234 5678 90",
    product_type: "savings_account",
    opening_date: "2021-06-01",
    balance: 10250.00
  }
];

const transactions =
[
  {
    "id": "5058a37a-69e3-49d9-bc08-1599d2710c94",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-03",
    "amount": -2819,
    "description": "Streaming Service"
  },
  {
    "id": "dfbc151d-87c1-4071-8f39-57e946c48a1b",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-04",
    "amount": -5659,
    "description": "Online Shopping"
  },
  {
    "id": "d09a1660-65a8-44f9-a153-61fb869a99f1",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-05",
    "amount": -8957,
    "description": "Insurance"
  },
  {
    "id": "a1d6ebca-47b1-4ca7-8ced-990c330db620",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-07",
    "amount": -5086,
    "description": "Electricity Bill"
  },
  {
    "id": "408b32c5-5f33-4bee-842c-788dde849b06",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-10",
    "amount": -4340,
    "description": "Phone Bill"
  },
  {
    "id": "86fb34b8-16c9-4e3e-a4d4-4caf437caf96",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-11",
    "amount": -6614,
    "description": "Phone Bill"
  },
  {
    "id": "b3cbf4ed-b9d1-4e76-b337-27bdce06e953",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-13",
    "amount": -1558,
    "description": "Insurance"
  },
  {
    "id": "95a1a7cb-39f7-4116-8bd4-687d4de197f9",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-13",
    "amount": -7946,
    "description": "Supermarket"
  },
  {
    "id": "489ce1ff-3ca7-41dd-bab3-a88b581a4e08",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-15",
    "amount": -7374,
    "description": "Electricity Bill"
  },
  {
    "id": "438c81c5-f19c-47c6-beec-56504402d75e",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-15",
    "amount": -9138,
    "description": "Insurance"
  },
  {
    "id": "993f04e8-672e-45b5-81f0-20a1236599f1",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-16",
    "amount": -4882,
    "description": "Pharmacy"
  },
  {
    "id": "39bbd619-1b1f-40f3-ab15-28911a64a401",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-18",
    "amount": -4264,
    "description": "Electricity Bill"
  },
  {
    "id": "b051134a-06d9-498a-88e7-59e0798d098d",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-19",
    "amount": -6924,
    "description": "Supermarket"
  },
  {
    "id": "f665888a-c421-48b2-acf4-1cc425ab21f5",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-21",
    "amount": -1988,
    "description": "Restaurant"
  },
  {
    "id": "a02a7c00-e05e-4520-adb2-1538e24b34d2",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-23",
    "amount": -9919,
    "description": "Online Shopping"
  },
  {
    "id": "8f982ead-7a66-46ab-af3d-d189929d78d8",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-24",
    "amount": -8084,
    "description": "Online Shopping"
  },
  {
    "id": "c896fe35-e177-4d76-8fe6-851283eb49b4",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-28",
    "amount": 300000,
    "description": "Salary Payment"
  },
  {
    "id": "e25ceacc-5ae5-4c93-8be0-6a8af805df33",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-28",
    "amount": -2778,
    "description": "Online Shopping"
  },
  {
    "id": "6ed908ed-cb66-47fc-b079-45328bc26e6c",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-29",
    "amount": -6326,
    "description": "Restaurant"
  },
  {
    "id": "441bbd31-b739-4aa0-be96-db0640f24a8b",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-06-30",
    "amount": -8769,
    "description": "Online Shopping"
  },
  {
    "id": "b9bdcdf5-c356-47bd-bb68-6942a7c300b3",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-02",
    "amount": -3021,
    "description": "Restaurant"
  },
  {
    "id": "d16a07fa-8447-4c1e-bdad-1453c823f55f",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-04",
    "amount": -9225,
    "description": "Streaming Service"
  },
  {
    "id": "2a09675f-06d3-48c9-b8db-b4ad0e3afc89",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-05",
    "amount": -3446,
    "description": "Electricity Bill"
  },
  {
    "id": "e35a0ce3-6d5a-4d07-9270-b9eb229eabf8",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-09",
    "amount": -2279,
    "description": "Phone Bill"
  },
  {
    "id": "422c3dc2-dafa-4119-986a-08304e2eef23",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-09",
    "amount": -8827,
    "description": "Online Shopping"
  },
  {
    "id": "6bea0e36-2254-4139-80f7-be949dab6981",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-11",
    "amount": -5459,
    "description": "Online Shopping"
  },
  {
    "id": "b4d55d22-868b-43b4-a8d8-0a1afef382c8",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-11",
    "amount": -6835,
    "description": "Insurance"
  },
  {
    "id": "8864a149-6afd-48ab-9553-e33b2adeb428",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-11",
    "amount": -2237,
    "description": "Restaurant"
  },
  {
    "id": "9a08d7f2-4dd9-419b-823c-b7a02580b4d1",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-17",
    "amount": -8103,
    "description": "Streaming Service"
  },
  {
    "id": "27701601-7c06-4770-b658-dcbda45de3e3",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-19",
    "amount": -6416,
    "description": "Electricity Bill"
  },
  {
    "id": "a10a1635-2e4f-4b52-ab25-9335200fee12",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-21",
    "amount": -7574,
    "description": "Online Shopping"
  },
  {
    "id": "5b41c0c2-bbea-44ee-8657-2dfd9f348e2b",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-22",
    "amount": -4529,
    "description": "Restaurant"
  },
  {
    "id": "eb59ec58-50aa-4213-81f0-c2aadf81bbc0",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-25",
    "amount": -7816,
    "description": "Insurance"
  },
  {
    "id": "a5a3b83d-feb5-46d4-80b9-c7f7dce8b9a2",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-26",
    "amount": -6383,
    "description": "Online Shopping"
  },
  {
    "id": "ca0866a4-5193-4b5c-bb06-0715d03e4c8a",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-27",
    "amount": -6809,
    "description": "Gym Membership"
  },
  {
    "id": "b9d6efb2-7f67-43e4-a877-2d3cb7d9ccb5",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-28",
    "amount": -9683,
    "description": "Electricity Bill"
  },
  {
    "id": "8f2d379b-a874-4a1f-8186-53e46f8f8750",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-29",
    "amount": 300000,
    "description": "Salary Payment"
  },
  {
    "id": "c575316c-8e61-42ac-8f43-adfedcd5eb0c",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-31",
    "amount": -8447,
    "description": "Restaurant"
  },
  {
    "id": "37375ec3-9bc0-4627-a767-bcb125f71e66",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-31",
    "amount": -3685,
    "description": "Supermarket"
  },
  {
    "id": "044c1539-5f15-4fec-9014-f230f9432606",
    "account_id": "9c453024-2997-4ce6-9834-abe544f8f380",
    "booking_date": "2025-07-31",
    "amount": -8958,
    "description": "Fuel"
  }
];

// Get account by ID
app.get('/api/accounts/:id', (req, res) => {
  success(`GET: account by account id ${req.params.id}`);
  const account = accounts.find(acc => acc.id === req.params.id);
  if (!account) return res.status(404).json({ message: 'Account not found' });
  res.json(account);
});

// Get transactions by account ID and date range
app.get('/api/accounts/:id/transactions', (req, res) => {
  const { id } = req.params;
  const { from, to } = req.query;
  success(`GET: all transactions for account id ${id} and from ${from} to to ${to}`);
  const fromDate = new Date(from);
  const toDate = new Date(to);
  const filteredById = transactions.filter(tx => tx.account_id == id);
  const filtered = transactions.filter(tx => 
    tx.account_id == id &&
    (!fromDate || new Date(tx.booking_date) >= fromDate) &&
    (!toDate || new Date(tx.booking_date) <= toDate)
  );

  res.json(filtered);
});

const PORT = process.env.PORT || 3002;
app.listen(PORT, () => {
  info(`Account Engine API running on port ${PORT}`);
});
