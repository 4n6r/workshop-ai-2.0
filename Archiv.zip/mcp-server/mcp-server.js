import express from "express";
import { McpServer, ResourceTemplate } from "@modelcontextprotocol/sdk/server/mcp.js"
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js"
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod"
import { contactResource } from "./resources/contacts-resource.js"

const app = express();
app.use(express.json());

const server = new McpServer({
    name: "MCP Server Boilerplate",
    version: "1.0.0"
})

server.registerResource("User Profile", "user://profile", {
    title: "User Profile - Get",
    description: "Returns the current users profile including name and person id."
},
    async (uri) => ({
        contents:
            [{
                uri: uri.href,
                text: JSON.stringify({ name: "Test User", person_id: "c30cd9c6-1ca8-4a48-a33e-d37de2dd7047" })
            }]
    }));

server.registerResource("Contacts - Get Contacts by Person Id", new ResourceTemplate("contacts://{personId}/contacts", { list: undefined }),
    {
        title: "Contacts - Get Contacts by Person Id",
        description: "Returns all of the contacts a person identified by its person id has stored in their profile.",
        mimeType: "application/json"
    },
    async (uri, { personId }) => {
        const response = await fetch(`http://localhost:3000/api/persons/${personId}/contacts`);
        if (!response.ok) throw new Error(`Failed to fetch contact for person with personID ${personId}`);

        const contacts = await response.json();
        return {
            contents:
                [{
                    uri: uri.href,
                    name: "contacts for person identified by person id",
                    text: JSON.stringify(contacts)
                }]
        }
    });

server.registerResource("Account Engine - Get Account by ID", new ResourceTemplate("accounts://{accountId}/get", { list: undefined }),
    {
        title: "Account Engine - Get Account by ID",
        description: "Returns the account based on its ID"
    },
    async (uri, { accountId }) => {
        const response = await fetch(`http://localhost:3002/api/accounts/${accountId}`);
        if (!response.ok) throw new Error(`Failed to fetch account for id ${accountId}`);

        const account = await response.json();
        return {
            contents:
                [{
                    uri: uri.href,
                    name: "Account Engine - Get Account by ID",
                    text: JSON.stringify(account)
                }]
        }
    });

server.registerResource("Account Engine - Get transactions by account ID and date range", new ResourceTemplate("accounts://{accountId}/transactions/{from}/{to}", { list: undefined }),
    {
        title: "Account Engine - Get transactions by account ID and date range",
        description: "Returns the transactions for an account based on the account id and a date range represented by from and to",
        inputSchema: {
            accountId: z.string().describe("The identifier representing the internal account id"),
            from: z.string().describe("The start date for the date range"),
            to: z.string().describe("The end date for the date range")
        }
    },
    async (uri, { accountId, from, to }) => {
        const response = await fetch(`http://localhost:3002/api/accounts/${accountId}/transactions?from=${from}&to=${to}`);
        if (!response.ok) throw new Error(`Failed to fetch transactions for id ${accountId} and range ${from} and ${to}`);

        const transactions = await response.json();
        return {
            contents:
                [{
                    uri: uri.href,
                    name: "Account Engine - Get transactions by account ID and date range",
                    text: JSON.stringify(transactions)
                }]
        }
    });

server.registerTool("Account Engine - Readable Transactions overview",
    {
        description: "This tool is used to get all transactions for an account specified by its internal account id and a date range and summarizes the overview",
        inputSchema: {
            accountId: z.string().describe("The identifier representing the internal account id"),
            from: z.string().describe("The start date for the date range"),
            to: z.string().describe("The end date for the date range")
        }
    },
    async ({ accountId, from, to }) => {
        const response = await fetch(`http://localhost:3002/api/accounts/${accountId}/transactions?from=${from}&to=${to}`);
        if (!response.ok) throw new Error(`Failed to fetch transactions for id ${accountId} and range ${from} and ${to}`);

        const transactions = await response.json();

        const samplingResponse = await server.server.createMessage({
        messages: [
            {
            role: "user",
            content: {
                type: "text",
                text: `Please summarize the following transactions and give the user a concise overview:\n\n${JSON.stringify(transactions)}`,
            },
            },
        ],
        maxTokens: 500,
        });
        return {
            contents:
                [{
                    name: "Account Engine - Readable Transactions overview",
                    text:  samplingResponse.content.type === "text" ? samplingResponse.content.text : "Unable to generate summary",
                }]
        }
    });

server.registerResource("Product Agreements - Get product agreements by person Id", new ResourceTemplate("product-agreements://products/person/{personId}", { list: undefined }),
    {
        title: "Product Agreements - Get product agreements by person Id",
        description: "Returns the product agreements assigned to a person identified by its person Id"
    },
    async (uri, { personId }) => {
        const response = await fetch(`http://localhost:3001/api/products/${personId}`);
        if (!response.ok) throw new Error(`Failed to fetch products for personId ${personId}`);

        const resp = await response.json();
        return {
            contents:
                [{
                    uri: uri.href,
                    name: "Product Agreements - Get product agreements by person Id",
                    text: JSON.stringify(resp)
                }]
        }
    });

server.registerTool("Order Manager - Send Transaction",
    {
        description: "This API is used to order transactions from an internal account represented by its id to another account represented by its IBAN",
        inputSchema: {
            sourceAccountId: z.string().describe("The identifier representing the internal account id"),
            targetIban: z.string().describe("The IBAN of the recipient"),
            recipient: z.string().describe("The name of the recipient"),
            description: z.string().describe("The description field for the transaction"),
            amount: z.number().describe("The amount to send")
        }
    }, async ({ sourceAccountId, targetIban, recipient, description, amount }) => {
        const result = await server.server.elicitInput({
            message: `Please confirm sending ${amount}€ to ${recipient} (${targetIban}) with description ${description}`,
            requestedSchema: {
                type: "object",
                properties: {
                    isCorrect: {
                        type: "boolean",
                        title: "Please confirm the transaction",
                        description: `Please confirm sending ${amount}€ to ${recipient} (${targetIban}) with description ${description}`
                    }
                },
                required: ["isCorrect"]
            }
        });

        if (result.content.isCorrect) {
            const response = await fetch(`http://localhost:3004/api/orders`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    sourceAccountId, targetIban, recipient, description, amount
                })
            });
            if (!response.ok) throw new Error(`Failed to post transaction`);
            const resp = await response.json();
            return {
                contents:
                    [{
                        name: "send transaction result",
                        text: JSON.stringify(resp)
                    }]
            }
        } else {
            throw new Error("Transaction canceled")
        }
    })

server.tool(
    "add",
    "Add two numbers",
    {
        a: z.number().describe("The first number"),
        b: z.number().describe("The second number"),
    },
    async ({ a, b }) => {
        const result = await server.server.elicitInput({
            message: `Please confirm your numbers ${a} and ${b}`,
            requestedSchema: {
                type: "object",
                properties: {
                    isCorrect: {
                        type: "boolean",
                        title: "Input is correct",
                        description: "Would you like me to check other dates?"
                    }
                },
                required: ["isCorrect"]
            }
        });

        console.log(result);
        if (result.content.isCorrect) {
            return { content: [{ type: "text", text: String(a + b) }] }
        } else {
            throw new Error("Tool aborted")
        }

    }
);





const transport = new StdioServerTransport()
await server.connect(transport)