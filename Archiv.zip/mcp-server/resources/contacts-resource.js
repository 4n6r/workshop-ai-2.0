import { z } from "zod";
import fetch from "node-fetch";

const ContactSchema = z.object({
  id: z.string().uuid(),
  name: z.string(),
  abbreviation: z.string(),
  phone: z.string(),
  iban: z.string()
});


export const contactResource = {
    schema: ContactSchema,  
    async getByPersonId(personId) {
        const response = await fetch(`http://localhost:3000/api/persons/${personId}/contacts`);
        if (!response.ok) throw new Error(`Failed to fetch contact for person with personID ${personId}`);

        const contact = await response.json();
        return ContactSchema.parse(contact);
    }
};
