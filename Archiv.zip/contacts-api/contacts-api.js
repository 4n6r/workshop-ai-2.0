import express from 'express';
import chalk from "chalk"

const app = express();

app.use(express.json());

const success = x => console.log(chalk.green(x));
const error = x => console.log(chalk.red(x));
const info = x => console.log(chalk.yellow(x));

const contacts = [
  {
    "person_id": "c30cd9c6-1ca8-4a48-a33e-d37de2dd7047",
    "id": "ff6af525-ca6e-4aec-a78c-0a5f9a1111b7",
    "name": "Alice Johnson",
    "abbreviation": "AJ",
    "phone": "+49-719-1174635",
    "iban": "DE32 8529 4853 8125 1227"
  },
  {
    "person_id": "c30cd9c6-1ca8-4a48-a33e-d37de2dd7047",
    "id": "78ebb696-2fbb-4082-8bb3-c3ba57e04b11",
    "name": "Bob Smith",
    "abbreviation": "BS",
    "phone": "+49-222-4434334",
    "iban": "DE54 8251 1188 9160 9807"
  },
  {
    "person_id": "c30cd9c6-1ca8-4a48-a33e-d37de2dd7047",
    "id": "65a7c195-76de-463c-8ec4-8418c0ca8ca6",
    "name": "Charlie Davis",
    "abbreviation": "CD",
    "phone": "+49-214-5921663",
    "iban": "DE84 9691 9680 9124 4602"
  },
  {
    "person_id": "c30cd9c6-1ca8-4a48-a33e-d37de2dd7047",
    "id": "ffda452c-cc51-4121-85fe-351bab06fa59",
    "name": "Diana Evans",
    "abbreviation": "DE",
    "phone": "+49-538-1578289",
    "iban": "DE51 4886 2243 6720 8034"
  },
  {
    "person_id": "c30cd9c6-1ca8-4a48-a33e-d37de2dd7047",
    "id": "20c895ac-fc48-4eb5-b1fd-2fe6638d868b",
    "name": "Ethan Brown",
    "abbreviation": "EB",
    "phone": "+49-871-2856553",
    "iban": "DE27 9161 3863 2136 8366"
  },
  {
    "person_id": "c30cd9c6-1ca8-4a48-a33e-d37de2dd7047",
    "id": "e12b1a50-d1e0-4f2c-8fb6-5734adb9f13a",
    "name": "Fiona Clark",
    "abbreviation": "FC",
    "phone": "+49-731-4515005",
    "iban": "DE81 6014 2271 8799 8057"
  },
  {
    "person_id": "c30cd9c6-1ca8-4a48-a33e-d37de2dd7047",
    "id": "8ff36b09-dfc4-4a30-89a1-c2ff211b5687",
    "name": "George Harris",
    "abbreviation": "GH",
    "phone": "+49-769-2887971",
    "iban": "DE80 3242 9287 6841 9612"
  },
  {
    "person_id": "c30cd9c6-1ca8-4a48-a33e-d37de2dd7047",
    "id": "95213702-b519-4748-91e5-6d107f5a22d6",
    "name": "Hannah Lewis",
    "abbreviation": "HL",
    "phone": "+49-298-2894599",
    "iban": "DE33 2436 8300 4643 9018"
  },
  {
    "person_id": "c30cd9c6-1ca8-4a48-a33e-d37de2dd7047",
    "id": "a8638975-657c-4568-a94f-5db19b8603be",
    "name": "Ian Moore",
    "abbreviation": "IM",
    "phone": "+49-965-7640346",
    "iban": "DE68 8231 4012 3959 6063"
  },
  {
    "person_id": "c30cd9c6-1ca8-4a48-a33e-d37de2dd7047",
    "id": "c570a614-acae-4913-a360-b187f2f2fd86",
    "name": "Julia Nelson",
    "abbreviation": "JN",
    "phone": "+49-678-3821874",
    "iban": "DE94 8244 3045 3712 3164"
  }
]

// Get all contacts for a person
app.get('/api/persons/:personId/contacts', (req, res) => {
  const { personId } = req.params;
  success(`GET: all contacts for person with personId ${personId}`);
  const filteredContacts = contacts.filter(e => e.person_id == personId) || [];
  res.json(filteredContacts);
});

// Create a new contact for a person
app.post('/api/persons/:personId/contacts', (req, res) => {
  const { personId } = req.params;
  const { name, abbreviation, phone, iban } = req.body;

  if (!name || !abbreviation || !phone || !iban) {
    error('All contact fields are required.')
    return res.status(400).json({ error: 'All contact fields are required.' });
  }

  const newContact = { id: Date.now().toString(), name, abbreviation, phone, iban };
  if (!persons[personId]) persons[personId] = [];
  persons[personId].push(newContact);

  res.status(201).json(newContact);
});

// Delete a contact by ID for a person
app.delete('/api/persons/:personId/contacts/:contactId', (req, res) => {
  const { personId, contactId } = req.params;
  const contacts = persons[personId];

  if (!contacts) {
    error('Person not found.')
    return res.status(404).json({ error: 'Person not found.' });
  } 

  const index = contacts.findIndex(c => c.id === contactId);
  if (index === -1) {
    error('Contact not found.');
    return res.status(404).json({ error: 'Contact not found.' });
  } 

  contacts.splice(index, 1);
  res.status(204).send();
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  info(`Contacts API running on port ${PORT}`);
});

