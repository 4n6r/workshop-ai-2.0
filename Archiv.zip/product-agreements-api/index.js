import express from 'express';
import {v4 as uuidv4} from 'uuid';
import chalk from 'chalk';
const app = express();

const log = console.log;

const success = x => console.log(chalk.green(x));
const error = x => console.log(chalk.red(x));
const info = x => console.log(chalk.yellow(x));

app.use(express.json());

const productStore = [
  {
    id: '9c453024-2997-4ce6-9834-abe544f8f380',
    person_id: 'c30cd9c6-1ca8-4a48-a33e-d37de2dd7047',
    type: 'current_account',
    name: 'Girokonto Plus',
    iban: 'DE89 3704 0044 0532 0130 00'
  },
  {
    id: 'd4e73883-06f4-4c30-9280-ee594547e7b4',
    person_id: 'c30cd9c6-1ca8-4a48-a33e-d37de2dd7047',
    type: 'mortgage',
    name: 'Immobilienkredit 2030',
    iban: null
  },
  {
    id: '828d4766-752b-4c25-8bc7-2ede631f2334',
    person_id: 'c30cd9c6-1ca8-4a48-a33e-d37de2dd7047',
    type: 'savings_account',
    name: 'Sparkonto Flex',
    iban: 'DE12 3456 7890 1234 5678 90'
  },
  {
    id: 'ea911d42-0691-428b-a918-f8f332629f02',
    person_id: 'c30cd9c6-1ca8-4a48-a33e-d37de2dd7047',
    type: 'investment',
    name: 'ETF Portfolio 70',
    iban: null
  }
];

app.get('/api/products/:person_id', (req, res) => {
  const { person_id } = req.params;
  success(`GET: products by person_id ${person_id}`);
  const products = productStore.filter(p => p.person_id === person_id);
  res.json(products);
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  info(`Product Agreements API running on port ${PORT}`);
});
